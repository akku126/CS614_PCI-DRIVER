#All source files along with the Makefile to compile the driver module must be placed here
## The make command must build a single module named cryptocard_mod.ko
